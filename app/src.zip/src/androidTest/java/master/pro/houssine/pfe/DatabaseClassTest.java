package master.pro.houssine.pfe;

import junit.framework.TestCase;

public class DatabaseClassTest extends TestCase {

}