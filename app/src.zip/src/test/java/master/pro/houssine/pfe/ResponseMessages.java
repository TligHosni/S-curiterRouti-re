package master.pro.houssine.pfe;

public class ResponseMessages {
}
