package master.pro.houssine.pfe.Response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ResponseAfficheContact implements Serializable {
    
    private int id, user_id,Vu;
    String name,phone,sujet,created_at;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSujet() {
        return sujet;
    }

    public void setSujet(String sujet) {
        this.sujet = sujet;
    }

    public int getVu() {
        return Vu;
    }

    public void setVu(int vu) {
        this.Vu = vu;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

//    @SerializedName("error")
//    @Expose
//    private Integer error;
//
//
//    @SerializedName("success")
//    @Expose
//    private Boolean succes;
//
//    @SerializedName("message")
//    @Expose
//    private String message;

    @SerializedName("cont")
    @Expose
    private String cont;


//    public Integer getError() {
//        return error;
//    }
//
//    public void setError(Integer error) {
//        this.error = error;
//    }
//
//
//    public String getMessage() {
//        return message;
//    }
//
//    public void setMessage(String message) {
//        this.message = message;
//    }
//
//    public Boolean getSucces() {
//        return succes;
//    }
//
//    public void setSucces(Boolean succes) {
//        this.succes = succes;
//    }

    public String getResult() {
        return cont;
    }

    public void setResult() {
        this.cont = cont;
    }


    
}
