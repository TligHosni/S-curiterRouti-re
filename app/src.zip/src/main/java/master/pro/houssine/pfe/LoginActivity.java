package master.pro.houssine.pfe;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import master.pro.houssine.pfe.Model.SharedPrefManger;
import master.pro.houssine.pfe.Response.ResponseLogin;
import master.pro.houssine.pfe.Retrofit.InterfaceAPI;
import master.pro.houssine.pfe.Retrofit.RetrofitClientInstance;
import master.pro.houssine.pfe.Utils.AppUtils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    EditText phone_txt;
    EditText password_txt;
    TextView forgetPassword;
    Button login;

    SharedPrefManger sharedPrefManger;

    FirebaseDatabase db = FirebaseDatabase.getInstance();
     DatabaseReference myRef = db.getReference("Users");

    @Override
    public void onBackPressed() {

        FragmentManager fm = getSupportFragmentManager();
        if (fm.getBackStackEntryCount() > 1) {
            fm.popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        AppUtils.getToken(getApplicationContext());
        login = (Button) findViewById(R.id.login);
        forgetPassword = (TextView) findViewById(R.id.forgetPassword);
        phone_txt = findViewById(R.id.phone);
        password_txt = findViewById(R.id.password);

        sharedPrefManger = new SharedPrefManger(getApplicationContext());

        login.setOnClickListener(new View.OnClickListener() {

                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onClick(View view){
                    String phone = phone_txt.getText().toString();
                    String password = password_txt.getText().toString();
                    myRef.setValue(phone,password);
                    login(phone, password);

                }
        });


        forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                VerifPass changePassDialog = new VerifPass();
                changePassDialog.show(getSupportFragmentManager(),"Pass Dialog Changer");

            }


        });
    }




    @Override
    protected void onStart() {

        super.onStart();
        if (sharedPrefManger.isLoggedIn()) {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
    }

    private void login(String phone, String password) {
        SharedPrefManger sharedPrefManger = new SharedPrefManger(LoginActivity.this);
        String token = sharedPrefManger.getStringSaved(getApplicationContext(), "token");
        InterfaceAPI api = RetrofitClientInstance.getRetrofitInstance().create(InterfaceAPI.class);
        Call<ResponseLogin> call = api.login("94311010", "1234", token);

        call.enqueue(new Callback<ResponseLogin>() {
            @Override
            public void onResponse(@NonNull Call<ResponseLogin> call, @NonNull Response<ResponseLogin> response) {

                if (response.isSuccessful()) {
                    if (response.body().getSucces()) {


//                        Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                        sharedPrefManger.saveUser(response.body().getUser());

                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);

                    } else {

                        Toast.makeText(LoginActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                    }

                } else {
                    Toast.makeText(LoginActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(@NonNull Call<ResponseLogin> call, @NonNull Throwable t) {
                Toast.makeText(LoginActivity.this, "Error : "+ t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


}

