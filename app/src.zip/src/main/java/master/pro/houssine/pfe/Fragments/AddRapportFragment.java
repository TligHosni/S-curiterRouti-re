package master.pro.houssine.pfe.Fragments;

import static android.app.Activity.RESULT_OK;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.MapView;
import com.squareup.picasso.Picasso;

import java.io.File;

import master.pro.houssine.pfe.Model.SharedPrefManger;
import master.pro.houssine.pfe.Model.User;
import master.pro.houssine.pfe.R;
import master.pro.houssine.pfe.Response.ResponseAddRapport;
import master.pro.houssine.pfe.Retrofit.InterfaceAPI;
import master.pro.houssine.pfe.Retrofit.RetrofitClientInstance;
import master.pro.houssine.pfe.Utils.AppUtils;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AddRapportFragment} factory method to
 * create an instance of this fragment.
 */
public class AddRapportFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;
    EditText typeU_txt, ageU_txt, sexeU_txt, vehicule_txt, vitesse_txt, alcole_txt, detailR_txt, detailE_txt, description_txt;
    MapView map;
    ImageView image;
    Button add, cancel;

    private int id;
    private Context context;
    private static Uri mImageUri;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_rapport, container, false);

        typeU_txt = view.findViewById(R.id.typeU);
        ageU_txt = view.findViewById(R.id.ageU);
        sexeU_txt = view.findViewById(R.id.sexeU);
        vehicule_txt = view.findViewById(R.id.vehicule);
        vitesse_txt = view.findViewById(R.id.vitesse);
        alcole_txt = view.findViewById(R.id.alcole);
        detailR_txt = view.findViewById(R.id.detailR);
        detailE_txt = view.findViewById(R.id.detailE);
        description_txt = view.findViewById(R.id.description);
        map = view.findViewById(R.id.map);
        map.onCreate(savedInstanceState);
        map.onResume();
        image = view.findViewById(R.id.image);
        add = view.findViewById(R.id.addR);
        cancel = view.findViewById(R.id.cancel);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = SharedPrefManger.getInstance(getActivity()).getUser();
                String latitude = user.getLatitude();
                String longitude = user.getLongitude();
                String typeUsager = typeU_txt.getText().toString();
                int ageUsager = Integer.parseInt(ageU_txt.getText().toString());
                String sexeUsager = sexeU_txt.getText().toString();
                String vehicule = vehicule_txt.getText().toString();
                String alcole = alcole_txt.getText().toString();
                String detailR = detailR_txt.getText().toString();
                String detailE = detailE_txt.getText().toString();
                String description = description_txt.getText().toString();
                String vitesse = vitesse_txt.getText().toString();


                add(latitude, longitude, typeUsager, sexeUsager, ageUsager, vehicule, alcole, vitesse, detailR, detailE, description);
            }
        });

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFileChooser();
            }
        });

        return view;
    }

    //Add Rapport



    //Add Images

    private void openFileChooser() {

        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
             mImageUri = data.getData();

            Picasso.get().load(mImageUri).into(image);

        }
    }
    private void add(String latitude, String longitude, String typeUsager, String sexeUsager, int ageUsager, String vehicule, String alcole, String vitesse, String detailR, String detailE, String description) {

        MultipartBody.Part image = null;

        File file = AppUtils.getFile(getContext(), Uri.parse(String.valueOf(mImageUri)));
        RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
        image = MultipartBody.Part.createFormData("image", file.getName(), reqFile);

        User user = SharedPrefManger.getInstance(getActivity()).getUser();
        int user_id = user.getId();

        InterfaceAPI api = RetrofitClientInstance.getRetrofitInstance().create(InterfaceAPI.class);
        Call<ResponseAddRapport> call = api.addRapport(latitude, longitude, typeUsager, ageUsager, sexeUsager, vehicule, vitesse, alcole, description, detailE, detailR,user_id, image);
        call.enqueue(new Callback<ResponseAddRapport>() {

            @Override
            public void onResponse(Call<ResponseAddRapport> call, Response<ResponseAddRapport> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getActivity(), "Error", Toast.LENGTH_SHORT).show();
                }

            }
            @Override
            public void onFailure(Call<ResponseAddRapport> call, Throwable t) {

            }
        });
    }


}
