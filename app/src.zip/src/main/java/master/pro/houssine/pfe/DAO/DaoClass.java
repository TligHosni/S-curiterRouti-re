package master.pro.houssine.pfe.DAO;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import master.pro.houssine.pfe.EntityClass.Contact;

import java.util.List;

@Dao
public interface DaoClass {

//    @Insert
//    void insertAllData(User model);
//
//    //Select All Data
//    @Query("select * from  users")
//    List<User> getAllData();
//
//    //DELETE DATA
//    @Query("delete from users where `id`= :id")
//    void deleteData(int id);
//
//    //Update Data
//
//    @Query("update users SET name= :name ,password = :password ,phone = :phone ,sexe = :sexe where `id`= :id")
//    void updateData(String name,String password, String phone, String sexe, int id);


    @Insert
    void insertAllData(Contact model);

    //Select All Data
    @Query("select * from  contacts")
    List<Contact> getAllData();

}
