package master.pro.houssine.pfe.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.ArrayList;
import java.util.List;

import master.pro.houssine.pfe.Adapter.MessageAdapter;
import master.pro.houssine.pfe.Model.SharedPrefManger;
import master.pro.houssine.pfe.Model.User;
import master.pro.houssine.pfe.R;
import master.pro.houssine.pfe.Response.ResponseAddMessage;
import master.pro.houssine.pfe.Response.ResponseAfficheMessage;
import master.pro.houssine.pfe.Response.ResponseMessage;
import master.pro.houssine.pfe.Retrofit.InterfaceAPI;
import master.pro.houssine.pfe.Retrofit.RetrofitClientInstance;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DiscussionFragment#} factory method to
 * create an instance of this fragment.
 */
public class DiscussionFragment extends Fragment {

    EditText message_txt;
    Button send_message, back;
    ListView recyclerView;
    LinearLayoutManager layoutManager;
    MessageAdapter adapter;
    List<ResponseAfficheMessage> messageList = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_discussion, container, false);

        message_txt = view.findViewById(R.id.message);
        send_message = view.findViewById(R.id.send_message);
        recyclerView = view.findViewById(R.id.recycler_view);
        back = view.findViewById(R.id.back);
        layoutManager = new LinearLayoutManager(getActivity());
        User user = SharedPrefManger.getInstance(getActivity()).getUser();
        affiche();


        send_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int user_id = user.getId();
                String message = message_txt.getText().toString();
                send(message);
                affiche();

            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContactFragment fragment = new ContactFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout, fragment);
                fragmentTransaction.commit();
            }
        });

        return view;
    }

    private void send(String message) {

        Bundle bundle = this.getArguments();
        int discussion_id = bundle.getInt("discussion_id");
        int user_id = bundle.getInt("user_id");

        InterfaceAPI api = RetrofitClientInstance.getRetrofitInstance().create(InterfaceAPI.class);

        Call<ResponseAddMessage> call = api.addMessage(discussion_id, message, user_id);
        call.enqueue(new Callback<ResponseAddMessage>() {
            @Override
            public void onResponse(Call<ResponseAddMessage> call, Response<ResponseAddMessage> response) {
                if (response.isSuccessful()) {

                    Toast.makeText(getActivity(), "Your message is send", Toast.LENGTH_LONG).show();
                    message_txt.setText("");
                } else {
                    Toast.makeText(getActivity(), "Error! Please tryy again.", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseAddMessage> call, Throwable t) {
                Toast.makeText(getContext(), "Failure add message ", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void affiche() {
        Bundle bundle = this.getArguments();
        int discussion_id = bundle.getInt("discussion_id");

            InterfaceAPI api = RetrofitClientInstance.getRetrofitInstance().create(InterfaceAPI.class);

            Call<ResponseMessage> call = api.listMessages(discussion_id);
            call.enqueue(new Callback<ResponseMessage>() {

                @Override
                public void onResponse(Call<ResponseMessage> call, Response<ResponseMessage> response) {

                    if (response.isSuccessful()) {


                        List<ResponseAfficheMessage> messageList = response.body().getResult();
                        MessageAdapter messageAdapter = new MessageAdapter(getActivity(), R.layout.right_item_message);
                        for (ResponseAfficheMessage message : messageList) {
                            messageAdapter.add(message);
                        }
                        recyclerView.setAdapter(messageAdapter);

                    } else {
                        Toast.makeText(getContext(), "Error! Please try again.", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<ResponseMessage> call, Throwable t) {
                    Toast.makeText(getContext(), "nooooo!!!", Toast.LENGTH_SHORT).show();
                }
            });

    }


}