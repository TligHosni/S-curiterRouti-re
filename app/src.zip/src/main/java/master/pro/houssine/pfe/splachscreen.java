package master.pro.houssine.pfe;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import master.pro.houssine.pfe.Model.SharedPrefManger;
import master.pro.houssine.pfe.Model.User;
import master.pro.houssine.pfe.Utils.AppUtils;

public class splachscreen extends AppCompatActivity {
    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splachscreen);

        AppUtils.getToken(getApplicationContext());
        User user = SharedPrefManger.getInstance(this).getUser();

        Thread splashScreenStarter = new Thread() {
            public void run() {
                try {
                    int delay = 0;
                    while (delay < 2000) {
                        sleep(200);
                        delay = delay + 100;
                    }

                    startActivity(new Intent(splachscreen.this, Maps_Citoyen.class));
//                    String phone = user.getPhone();
//
//                    if(phone != null) {
//
//                        startActivity(new Intent(splachscreen.this, MainActivity.class));
//
//                    }else{
//
//                        startActivity(new Intent(splachscreen.this, LoginActivity.class));
//
//                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    finish();
                }
            }

        };
        splashScreenStarter.start();

    }

}