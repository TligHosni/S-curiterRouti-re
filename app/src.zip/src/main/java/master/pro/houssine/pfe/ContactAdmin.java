package master.pro.houssine.pfe;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ContactAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_admin);
    }
}