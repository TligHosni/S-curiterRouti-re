package master.pro.houssine.pfe;

import static master.pro.houssine.pfe.databinding.ActivityMainBinding.inflate;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import master.pro.houssine.pfe.Firebase.FirebaseDataReceiver;
import master.pro.houssine.pfe.Fragments.AlarmFragment;
import master.pro.houssine.pfe.Fragments.ContactFragment;
import master.pro.houssine.pfe.Fragments.DiscussionFragment;
import master.pro.houssine.pfe.Fragments.HomeFragment;
import master.pro.houssine.pfe.Fragments.NotifFragment;
import master.pro.houssine.pfe.Fragments.NotificationsFragment;
import master.pro.houssine.pfe.Fragments.ProfilFragment;
import master.pro.houssine.pfe.Fragments.RapportListeFragment;
import master.pro.houssine.pfe.Fragments.contactU;
import master.pro.houssine.pfe.Model.SharedPrefManger;
import master.pro.houssine.pfe.Model.User;
import master.pro.houssine.pfe.Response.ResponseDeleteToken;
import master.pro.houssine.pfe.Response.ResponseNbrNotif;
import master.pro.houssine.pfe.Response.ResponseUpdateAccident;
import master.pro.houssine.pfe.Retrofit.InterfaceAPI;
import master.pro.houssine.pfe.Retrofit.RetrofitClientInstance;
import master.pro.houssine.pfe.Services.LocationService;
import master.pro.houssine.pfe.Utils.AppUtils;
import master.pro.houssine.pfe.databinding.ActivityMainBinding;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity<mMessageReceiver> extends AppCompatActivity /*implements NavigationView.OnNavigationItemSelectedListener*/ {

    ActivityMainBinding binding;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    BottomNavigationView navigationView;
    BottomAppBar bottomAppBar;
    Toolbar toolbar;
    View name;
    SharedPrefManger sharedPrefManger;
    TextView txtName;
    static TextView notification_Badge;
    View notificationIndicator;
    LinearLayout linProfile, linHome, linlogout, linalarm, linnotif;
    private LocListener locationListener;
    CircleImageView image_user;
    BottomNavigationView bottomNavigationView;
    public static FirebaseDataReceiver firebaseDataReceiver;


    public static void openDrawer(DrawerLayout drawerLayout) {

        drawerLayout.openDrawer(GravityCompat.START);
    }

    public static void closeDrawer(DrawerLayout drawerLayout) {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }

    }

    public static void redirectActivity(Activity activity, Class aclasse) {
        Intent intent = new Intent(activity, aclasse);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);

    }

    @Override
    public void onBackPressed() {

        FragmentManager fm = getSupportFragmentManager();
        if (fm.getBackStackEntryCount() > 1) {
            fm.popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkLocationPermission();
        }

//        LocalBroadcastManager.getInstance(this).registerReceiver((mMessageReceiver), new IntentFilter("MyData"));

    }

    @SuppressLint({"NonConstantResourceId", "RestrictedApi", "WrongViewCast", "CutPasteId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        User user = SharedPrefManger.getInstance(this).getUser();
        drawerLayout = findViewById(R.id.drawer_layout);
        txtName = drawerLayout.findViewById(R.id.name);
        image_user = drawerLayout.findViewById(R.id.image);
        linProfile = drawerLayout.findViewById(R.id.linProfile);
        linHome = drawerLayout.findViewById(R.id.linHome);
        linlogout = drawerLayout.findViewById(R.id.logout);
        linalarm = drawerLayout.findViewById(R.id.linalarm);
        linnotif = drawerLayout.findViewById(R.id.linnotif);
        notification_Badge = findViewById(R.id.notification_Badge);
        bottomNavigationView = findViewById(R.id.buttonPanel);
        //  bottomAppBar = findViewById(R.id.bottomappbar);


        if (getIntent().getExtras() != null) {
            Intent intent = getIntent();
            String type = intent.getStringExtra("type");
            String element = intent.getStringExtra("element");
            int d_id = Integer.parseInt(element);
            String from = intent.getStringExtra("from");


            if (!type.equals("message")) {
                replaceFragement(new HomeFragment());
                if (from.equals("dataReceiver")) {
                    updateAccident(element);
                }
            } else {
                if (from.equals("dataReceiver")) {
                    AppCompatActivity activity = MainActivity.this;
                    Bundle bundle = new Bundle();
                    bundle.putInt("discussion_id", d_id);
                    DiscussionFragment fragment = new DiscussionFragment();
                    fragment.setArguments(bundle);
                    fragment.setArguments(bundle);
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragment).commit();
                    replaceFragement(new ContactFragment());
                }
            }
        }


        final Handler handler = new Handler();
        Runnable refresh = new Runnable() {
            @Override
            public void run() {
                // data request
                handler.postDelayed(this, 20);
            }
        };
        handler.postDelayed(refresh, 20);

        nbrNotif();

        if (user != null) {

            txtName.setText(user.getName());

            image_user.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    replaceFragement(new ProfilFragment());
                }
            });

            String imageurl = SharedPrefManger.getInstance(this).getUser().getImage();
            String url = RetrofitClientInstance.API_BASE_URL_IMAGE + imageurl;
            Glide.with(MainActivity.this)
                    .load(url)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(new RequestListener<Drawable>() {

                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            return false;
                        }
                    })
                    .into(image_user);

        }

        linProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this, "Profile clickeddddddd ... ", Toast.LENGTH_SHORT).show();
                replaceFragement(new ProfilFragment());
            }
        });

        Toast.makeText(MainActivity.this, "Token : " + AppUtils.getToken(getApplicationContext()), Toast.LENGTH_SHORT).show();

        linHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this, "Profile clickeddddddd ... ", Toast.LENGTH_SHORT).show();
                replaceFragement(new HomeFragment());
            }
        });

        linlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteToken();
                SharedPrefManger.getInstance(MainActivity.this).clear();
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });

        linalarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this, "home clicked ... ", Toast.LENGTH_SHORT).show();
                replaceFragement(new AlarmFragment());
            }
        });

        linnotif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this, "home clicked ... ", Toast.LENGTH_SHORT).show();
                replaceFragement(new NotifFragment());

            }
        });

        Intent servIntent = new Intent(getApplicationContext(), LocationService.class);
        startService(servIntent);
//        Toast.makeText(MainActivity.this, "Location service activated ... ", Toast.LENGTH_SHORT).show();

        locationListener = new LocListener();

        replaceFragement(new HomeFragment());
        binding.buttonPanel.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {

                case R.id.home:
                    replaceFragement(new HomeFragment());
                    break;

                case R.id.Rapports:
                    replaceFragement(new RapportListeFragment());
                    break;

                case R.id.Notification:
                    replaceFragement(new NotificationsFragment());


                    break;

                case R.id.contact:
                    replaceFragement(new contactU());
                    break;
            }
            return true;
        });


        // This callback will only be called when MyFragment is at least Started.
        OnBackPressedCallback callback = new OnBackPressedCallback(true /* enabled by default */) {
            @Override
            public void handleOnBackPressed() {
                HomeFragment fragment = new HomeFragment();
                FragmentManager fragmentManager = Objects.requireNonNull(MainActivity.this).getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout, fragment);
                fragmentTransaction.commit();
            }
        };
        this.getOnBackPressedDispatcher().addCallback(this, callback);

        // The callback can be enabled or disabled here or in handleOnBackPressed()

    }

    private void deleteToken() {
        User user = SharedPrefManger.getInstance(MainActivity.this).getUser();
        int user_id = user.getId();
        String token = sharedPrefManger.getStringSaved(getApplicationContext(), "token");
        InterfaceAPI api = RetrofitClientInstance.getRetrofitInstance().create(InterfaceAPI.class);

        Call<ResponseDeleteToken> call = api.deleteToken(token, user_id);
        call.enqueue(new Callback<ResponseDeleteToken>() {

            @Override
            public void onResponse(Call<ResponseDeleteToken> call, Response<ResponseDeleteToken> response) {
                Toast.makeText(MainActivity.this, "Token deleted...", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onFailure(Call<ResponseDeleteToken> call, Throwable t) {

            }
        });
    }

    private void nbrNotif() {

        User user = SharedPrefManger.getInstance(MainActivity.this).getUser();
        int user_id = user.getId();

        InterfaceAPI api = RetrofitClientInstance.getRetrofitInstance().create(InterfaceAPI.class);

        Call<ResponseNbrNotif> call = api.NbrNotif(user_id);
        call.enqueue(new Callback<ResponseNbrNotif>() {

            @Override
            public void onResponse(Call<ResponseNbrNotif> call, Response<ResponseNbrNotif> response) {
                if (response.isSuccessful()) {
                    if (response.body().getNotif() > 0) {
                        notification_Badge.setText(String.valueOf(response.body().getNotif()));
                        notification_Badge.setVisibility(View.VISIBLE);
                    } else {
                        notification_Badge.setVisibility(View.INVISIBLE);
                    }

                } else {
                    Toast.makeText(MainActivity.this, "Error! Please try again.", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseNbrNotif> call, Throwable t) {
            }
        });

    }

    public static void visibleBadge() {
        notification_Badge.setVisibility(View.INVISIBLE);
    }


    private void replaceFragement(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();

    }


    public void ClickMenu(View view) {
        //Open drawer
        openDrawer(drawerLayout);
    }

    public void ClickLogo(View view) {
        closeDrawer(drawerLayout);
    }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawerLayout);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 99);
            } else {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 99);

            }

            return false;

        } else {
            return true;
        }

    }

    public static class LocListener implements android.location.LocationListener {
        Context context;

        @Override
        public void onLocationChanged(Location location) {
            float distanceInMeters = 1;
            if (location != null) {

                Toast.makeText(context, "location Main : " + location.getLatitude() + " // " + location.getLongitude(), Toast.LENGTH_SHORT).show();

                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("user_locations");
                GeoFire geoFire = new GeoFire(ref);
                geoFire.setLocation(String.valueOf(SharedPrefManger.getInstance(context).getUser().getId()),
                        new GeoLocation(location.getLatitude(), location.getLongitude()), new GeoFire.CompletionListener() {
                            @SuppressLint("LongLogTag")
                            @Override
                            public void onComplete(String key, DatabaseError error) {
                                if (error != null) {
                                    Log.d("geolocation!", location.getLatitude() + "" + location.getLongitude());
                                } else {
                                    Log.d("location sended successfully!", "success");
                                }

                            }
                        });
            }


        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    }

    final BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String type = intent.getStringExtra("type");
            String element = intent.getStringExtra("element");
            String from = intent.getStringExtra("from");
            int d_id = Integer.parseInt(element);

            AppCompatActivity activity = MainActivity.this;
            if (type.equals("message")) {
                Bundle bundle = new Bundle();
                bundle.putInt("discussion_id", d_id);
                DiscussionFragment fragment = new DiscussionFragment();
                fragment.setArguments(bundle);
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragment).commit();
                replaceFragement(new ContactFragment());
            } else {
                replaceFragement(new HomeFragment());
                if (from.equals("dataReceiver")) {
                    updateAccident(element);
                }

            }
        }
    };

    private void updateAccident(String intentelement) {

        InterfaceAPI api = RetrofitClientInstance.getRetrofitInstance().create(InterfaceAPI.class);

        Call<ResponseUpdateAccident> call = api.updateAccident(Integer.parseInt(intentelement));
        call.enqueue(new Callback<ResponseUpdateAccident>() {
            @Override
            public void onResponse(Call<ResponseUpdateAccident> call, Response<ResponseUpdateAccident> response) {
                Toast.makeText(MainActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ResponseUpdateAccident> call, Throwable t) {
                Toast.makeText(MainActivity.this, "noooooo....rrrrr", Toast.LENGTH_SHORT).show();
            }
        });

    }
}






