package master.pro.houssine.pfe;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import master.pro.houssine.pfe.Fragments.MapFragment;
import master.pro.houssine.pfe.Model.SharedPrefManger;

public class Maps_Citoyen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_citoyen);

       SharedPrefManger sharedPrefManger = new SharedPrefManger(getApplicationContext());

        super.onStart();
        if (sharedPrefManger.isLoggedIn()) {
            Intent intent = new Intent(Maps_Citoyen.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }

        //initiliaze fragment
        Fragment fragment = new MapFragment();

        //open fragment
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.frame_maps,fragment)
                .commit();
    }

}